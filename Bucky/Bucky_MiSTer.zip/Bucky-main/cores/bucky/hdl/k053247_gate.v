// ─────────────────────────────────────────────────────────────────────────────────────────────
// FORK COWBOYS del motor de dibujado de sprites (rol del 053247). Origen: modules/jtframe/hdl/video|ram.
// Clonado 2026-07-20 (ses.27) para el datapath 64-bit interno + dibujado a 2 px/clk con line buffer de
// doble banco (par/impar). PASO 1: copia 1:1 renombrada (1 px/clk, comportamiento IDENTICO) -> checkpoint
// verificable antes de tocar throughput. Renombrado para NO quedar sombreado por el original en el orden
// -y de verilator/quartus (misma trampa que cowboys_obj / k053246*). Ver HANDOFF ses.27 + memoria
// cowboys-lyro-64bit-sdram-infeasible. jtframe NO se toca.
// ─────────────────────────────────────────────────────────────────────────────────────────────
/*  This file is part of JTFRAME.
    JTFRAME program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    JTFRAME program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with JTFRAME.  If not, see <http://www.gnu.org/licenses/>.

    Author: Jose Tejada Gomez. Twitter: @topapate
    Version: 1.0
    Date: 18-12-2022 */

// Draws 16x16 sprites in a double-line buffer
// Assumes that the inputs are still during drawing,
// otherwise set LATCH=1
// LATCH=1 will introduce an extra 1-clock per drawing
// operation, so use LATCH=0 when throughput is critical

// Shadow operation follows TMNT style: an independent bit sets
// shadow for the pixel independently of the pixel color. The
// shadow bit is always written, even if the pixel is blank.
// The shadow bit must be the MSB

`ifndef BUCKY_TEST_PLUSARGS
`ifdef SYNTHESIS
`define BUCKY_TEST_PLUSARGS(arg) 1'b0
`else
`define BUCKY_TEST_PLUSARGS(arg) $test$plusargs(arg)
`endif
`endif

module k053247_gate #( parameter
    AW    =  9,    // Buffer with
    CW    = 12,    // code width
    PW    =  8,    // pixel width (lower four bits come from ROM)
    ZW    =  6,    // zoom step width - see description in jtframe_draw
    ZI    = ZW-1,  // integer part of the zoom width
    ZENLARGE= 0,   // enable zoom enlarging
    SWAPH =  0,    // swaps the two horizontal halves of the tile
    HJUMP =  0,    // set to 0 if hdump is a continuous count
                   // set to 1 if hdump jumps from  FF to 180  (like KIWI)
                   // set to 2 if hdump jumps from 1FF to  80  (like JTTORA)
                   // See note below about hdump fix for HJUMP==0
    HFIX  =  1,    // Fixes some problems, but it may create others. Turn it off if objects are not rendered on part of the screen
    LATCH =  0,    // If set, latches code, xpos, ysub, hflip, vflip and pal when draw is set and busy is low
    FLIP_OFFSET=0, // Added to ~hdump when flip==1 and HJUMP==0
    KEEP_OLD   =0, // new writes do not overwrite old ones (reverse priority)
    BUFDLY     =0, // extra latency to add to buf_addr and buf_we, use if buf_din is not combinational
    ALPHAW     =4,
    ALPHA      =0,
    SHADOW     =0, // 1 for shadows
    SW         =1, // Shadow bits width (Use with SHADOW==1)
    SHADOW_PEN = ALPHA, // Value used by only-shadow sprites. Use independently from SHADOW
    // object line buffer
    PACKED     =0  // 0 if rom_data is { plane3, plane2, plane1, plane0 }, 8 bits each
                   // 1 if rom_data packs the 4 planes in nibbles
)(
    input               rst,
    input               clk,
    input               pxl_cen,
    input               hs,
    input               flip,
    input    [AW-1:0]   hdump,

    input               draw,
    output              busy,
    input    [CW-1:0]   code,
    input    [AW-1:0]   xpos,
    input      [ 3:0]   ysub,
    // Truncate to first 8 or 4 bits
    input      [ 1:0]   trunc, // 00=no trunc, 10 = 8 pixels, 11 = 4 pixels
    // optional zoom, keep at zero for no zoom
    input    [ZW-1:0]   hzoom,
    input               hz_keep, // set at 1 for the first tile

    input               hflip,
    input               vflip,
    input      [PW-5:0] pal,

    output     [CW+6:2] rom_addr, // {code,H,Y}
    output              rom_cs,
    input               rom_ok,
    input      [31:0]   rom_data,

    output     [PW-1:0] buf_pred,   // line buffer data to be altered and
    input      [PW-1:0] buf_din,    // then fed back through these ports

    output     [PW-1:0] pxl
);

reg  [AW-1:0] aeff, hdf, hdfix;
wire [AW-1:0] adly;

reg  [CW-1:0] dr_code;
reg  [AW-1:0] dr_xpos;
reg    [ 3:0] dr_ysub;
reg           dr_hflip, dr_vflip, dr_draw;
reg  [PW-5:0] dr_pal;

reg  [ZW-1:0] dr_hzoom;
reg           dr_hz_keep;

wire [AW-1:0] buf_addr;
wire          buf_we, we_dly;
// ── PASO 2b: 2o pixel (px_hi) del dibujante -> puerto B del buffer ──
wire [AW-1:0] buf_addr2;
wire          buf_we2;
wire [PW-1:0] buf_din2;
// ── ses.30: 4 px/clk -> puertos C y D del buffer (buf_addr = buf_addr+2 / +3) ──
wire [AW-1:0] buf_addr3, buf_addr4;
wire          buf_we3,   buf_we4;
wire [PW-1:0] buf_din3,  buf_din4;
wire   [31:0] rom_sorted;

wire          pre_bsy;
wire          dr_active;
reg           late_hs_l, discard_late_draw;

// The scanner restarts at each HS even if the final tile from the preceding
// line is still being emitted.  Once the ping-pong buffer flips, those pixels
// no longer own the producer bank: accepting them would draw an opaque block
// into the following line.  Drop only that in-flight tail; the next tile is
// accepted after the draw stage becomes idle.
always @(posedge clk, posedge rst) begin
    if( rst ) begin
        late_hs_l        <= 1'b0;
        discard_late_draw<= 1'b0;
    end else begin
        late_hs_l <= hs;
        if( hs && !late_hs_l && dr_active ) discard_late_draw <= 1'b1;
        else if( !dr_active )                discard_late_draw <= 1'b0;
    end
end

wire line_owner_ok = !discard_late_draw;

assign rom_sorted = PACKED==0 ? rom_data :
{rom_data[31], rom_data[27], rom_data[23], rom_data[19], rom_data[15], rom_data[11], rom_data[7], rom_data[3],
 rom_data[30], rom_data[26], rom_data[22], rom_data[18], rom_data[14], rom_data[10], rom_data[6], rom_data[2],
 rom_data[29], rom_data[25], rom_data[21], rom_data[17], rom_data[13], rom_data[ 9], rom_data[5], rom_data[1],
 rom_data[28], rom_data[24], rom_data[20], rom_data[16], rom_data[12], rom_data[ 8], rom_data[4], rom_data[0] };

generate
    if( LATCH ) begin
        always @(posedge clk) begin
            dr_draw <= draw;
            if( !pre_bsy ) begin
                dr_code    <= code;
                dr_xpos    <= xpos;
                dr_ysub    <= ysub;
                dr_hflip   <= hflip;
                dr_vflip   <= vflip;
                dr_pal     <= pal;
                dr_hzoom   <= hzoom;
                dr_hz_keep <= hz_keep;
            end
        end
        assign busy = pre_bsy | dr_draw; // busy is always assert 1 clock cycle after draw
    end else begin
        always @* begin
            dr_draw    = draw;
            dr_code    = code;
            dr_xpos    = xpos;
            dr_ysub    = ysub;
            dr_hflip   = hflip;
            dr_vflip   = vflip;
            dr_pal     = pal;
            dr_hzoom   = hzoom;
            dr_hz_keep = hz_keep;
        end
        assign busy = pre_bsy;
    end
endgenerate

always @* begin
    aeff = 0;
    hdf  = 0;
    case( HJUMP ) //1 and 2 only work using 9 bits
        1: begin
            aeff[8:0] = { buf_addr[8], buf_addr[8] ^ buf_addr[7], buf_addr[6:0] }; // 100~17F is translated to 180~1FF, and 180~1FF to 100~17F
            hdf  = hdump ^ { {AW-8{1'b0}}, flip&~hdump[8], {7{flip}} };
        end
        2: begin
            aeff[8:0] = { buf_addr[8],~buf_addr[8] | buf_addr[7], buf_addr[6:0] }; //  00~ 7F is translated to  80~ FF
            hdf  = hdump ^ { {AW-8{1'b0}}, flip&hdump[8], {7{flip}} }; // untested line
        end
        default: begin
            aeff = buf_addr;
            hdf  = flip ? ~hdfix+FLIP_OFFSET[8:0] : hdfix;
        end
    endcase
end

generate
    if(HJUMP==0 && HFIX==1) begin
        // For HJUMP==0, it is common that the readout counter wraps around a bit before
        // horizontal blank. That may read pixel data written to the start of the blank
        // region instead of continuing the regular count. An example of this is
        // scontra's final game boss. As it appears from the top (left unrotated) side
        // of the screen, part of it is visible at the bottom (right).
        // Instead of configuring this per game using macros, I have opted for detecting
        // the situation generally and fixing it. The readout count will keep increasing
        // until HS is hit.
        always @(posedge clk) begin
            if( rst ) begin
                hdfix <= 0;
            end else if(pxl_cen) begin
                hdfix <= ( hdump > hdfix || hs ) ? hdump+9'd1 : hdfix+9'd1;
            end
        end
    end else begin
        always @* hdfix=hdump;
    end
endgenerate

// ── SONDA VENTANA DE READOUT (ses.36, solo sim): mide el rango REAL de rd_addr (hdf) leido durante
//    linea activa (~hs). Es la VERDAD de que posiciones de buffer son VISIBLES — la base del cull-X.
//    ses.35 asumio [4..387] sin medirlo y rompio la placa; aqui se mide y se imprime al cambiar min/max.
`ifdef VERILATOR
wire diag_en = `BUCKY_TEST_PLUSARGS("DIAG");
// MAPA REAL columna->hdf del readout (RTL, sin replicas del tb). Cuenta pxl_cen desde hs y publica el hdf
// leido en cada columna, deduplicado (mismo patron cada linea). Revela el rango REAL de buf_addr mostrado.
integer  rdcol=0;
reg      rdseen_c [0:511];
integer  ri;
initial for(ri=0;ri<512;ri=ri+1) rdseen_c[ri]=0;
reg hs_pl=0;
always @(posedge clk) begin
    hs_pl <= hs;
    if( hs ) rdcol <= 0;
    else if( pxl_cen ) begin
        if( rdcol<512 && !rdseen_c[rdcol] ) begin
            rdseen_c[rdcol] <= 1'b1;
            if (diag_en) $display("RDMAP col=%0d hdf=%0d", rdcol, hdf);
        end
        rdcol <= rdcol + 1;
    end
end
`endif

generate
    if(BUFDLY==0) begin
        assign adly   = aeff,
               we_dly = buf_we;
    end else begin
        jtframe_sh #(.L(BUFDLY),.W(1+AW)) u_sh(
            .clk    ( clk           ),
            .clk_en ( 1'b1          ),
            .din    ( {aeff,buf_we} ),
            .drop   ( {adly,we_dly} )
        );
    end
endgenerate

k053247_draw #(
    .AW      ( AW       ),
    .CW      ( CW       ),
    .PW      ( PW       ),
    .ZW      ( ZW       ),
    .ZI      ( ZI       ),
    .ZENLARGE( ZENLARGE ),
    .SWAPH   ( SWAPH    ),
    .KEEP_OLD( KEEP_OLD )
)u_draw(
    .rst        ( rst       ),
    .clk        ( clk       ),
    .draw       ( dr_draw   ),
    .busy       ( pre_bsy   ),
    .draw_busy  ( dr_active ),
    .code       ( dr_code   ),
    .xpos       ( dr_xpos   ),
    .ysub       ( dr_ysub   ),
    .trunc      ( trunc     ),
    .hz_keep    ( dr_hz_keep),
    .hzoom      ( dr_hzoom  ),
    .hflip      ( dr_hflip  ),
    .vflip      ( dr_vflip  ),
    .pal        ( dr_pal    ),
    .rom_addr   ( rom_addr  ),
    .rom_cs     ( rom_cs    ),
    .rom_ok     ( rom_ok    ),
    .rom_data   ( rom_sorted),

    .buf_addr   ( buf_addr  ),
    .buf_we     ( buf_we    ),
    .buf_din    ( buf_pred  ),
    .buf_addr2  ( buf_addr2 ),
    .buf_we2    ( buf_we2   ),
    .buf_din2   ( buf_din2  ),
    .buf_addr3  ( buf_addr3 ),
    .buf_we3    ( buf_we3   ),
    .buf_din3   ( buf_din3  ),
    .buf_addr4  ( buf_addr4 ),
    .buf_we4    ( buf_we4   ),
    .buf_din4   ( buf_din4  )
);

k053247_buffer #(
    .AW         ( AW          ),
    .DW         ( PW          ),
    .ALPHAW     ( ALPHAW      ),
    .ALPHA      ( ALPHA       ),
    .SW         ( SW          ),
    .SHADOW     ( SHADOW      ),
    .SHADOW_PEN ( SHADOW_PEN  ),
    .KEEP_OLD   ( KEEP_OLD    )
) u_linebuf(
    .rst        ( rst       ),
    .clk        ( clk       ),
    .flip       ( 1'b0      ),      // flip is solved before this instance
    .LHBL       ( ~hs       ),
    // New line writting — puerto A (px_lo)
    .we         ( we_dly  & line_owner_ok ),
    .wr_data    ( buf_din   ),
    .wr_addr    ( adly      ),
    // Puertos B/C/D (px 1/2/3) — 4 px/clk (ses.30). Con HJUMP=0/BUFDLY=0 la direccion de escritura
    // no lleva transformada (aeff=buf_addr) => van directas como buf_addr2/3/4.
    .we2        ( buf_we2 & line_owner_ok ),
    .wr_data2   ( buf_din2  ),
    .wr_addr2   ( buf_addr2 ),
    .we3        ( buf_we3 & line_owner_ok ),
    .wr_data3   ( buf_din3  ),
    .wr_addr3   ( buf_addr3 ),
    .we4        ( buf_we4 & line_owner_ok ),
    .wr_data4   ( buf_din4  ),
    .wr_addr4   ( buf_addr4 ),
    // Previous line reading
    .rd         ( pxl_cen   ),
    .rd_addr    ( hdf       ),
    .rd_data    ( pxl       )
);

endmodule
