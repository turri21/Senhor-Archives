/*
 * Open jt539 compatibility wrapper for JTFRAME/JTCORES
 *
 * Interface reconstructed from public JTCORES instantiations
 * (not from the private jt539 implementation).
 *
 * Backend:
 *   jlrh/konami-fpga k054539.v (GPL-3.0)
 *
 * Notes:
 * - JTCORE's public jt539 interface has no rom_ok. JTFRAME gates cen_pcm
 *   against the PCM SDRAM buses, so the backend's rom_ok is tied high.
 * - The backend's timeout is currently unused; this wrapper implements the
 *   K054539 timer output from writes to folded registers 0x127/0x12f.
 * - aux_l/aux_r are mixed into the backend PCM output with signed saturation.
 */

module jt539 #(
    parameter VOLSHIFT = 0
)(
    input                       rst,
    input                       clk,
    input                       cen,
    output                      timeout,

    // CPU interface: folded K054539 address {A[9],A[7:0]}
    input      [8:0]            addr,
    input                       we,
    input                       rd,
    input                       cs,
    input      [7:0]            din,
    output     [7:0]            dout,

    // PCM sample ROM
    output                      rom_cs,
    output     [23:0]           rom_addr,
    input      [7:0]            rom_data,

    // Auxiliary stereo input used by dual-K054539 boards
    input signed [15:0]         aux_l,
    input signed [15:0]         aux_r,

    // Sound output
    output signed [15:0]        left,
    output signed [15:0]        right,

    // JTFRAME debug
    input      [7:0]            debug_bus,
    output     [7:0]            st_dout
);

wire signed [15:0] pcm_l;
wire signed [15:0] pcm_r;
wire backend_timeout_unused;

/*
 * The public k054539 backend waits on rom_ok. In the public JT539 users
 * (e.g. rungun), the PCM bus has no rom_ok; instead cen_pcm is generated
 * with JTFRAME memory gating. Therefore a high rom_ok is the closest
 * source-compatible translation of that contract.
 */
k054539 #(.VOLSHIFT(VOLSHIFT)) u_k054539 (
    .rst       ( rst                    ),
    .clk       ( clk                    ),
    .cen       ( cen                    ),
    .timeout   ( backend_timeout_unused ),

    .addr      ( addr                   ),
    .we        ( we                     ),
    .rd        ( rd                     ),
    .cs        ( cs                     ),
    .din       ( din                    ),
    .dout      ( dout                   ),

    .rom_cs    ( rom_cs                 ),
    .rom_addr  ( rom_addr               ),
    .rom_data  ( rom_data               ),
    .rom_ok    ( 1'b1                   ),

    .left      ( pcm_l                  ),
    .right     ( pcm_r                  ),

    .debug_bus ( debug_bus              ),
    .st_dout   ( st_dout                )
);

/*
 * K054539 timer
 *
 * Real register addresses:
 *   0x227 : timer frequency
 *   0x22f : global control, bit 5 enables timer output
 *
 * With the chip's A8 omitted from the external bus these appear as:
 *   9'h127 and 9'h12f.
 *
 * MAME's model toggles the timer callback at:
 *
 *   half_period_cen = 2,764,800 / (38 + timer_reg)
 *
 * when cen represents the 18.432 MHz K054539 clock.
 *
 * Using a phase accumulator avoids integer-divider frequency error.
 */
reg [7:0]  timer_reg;
reg        timer_enable;
reg        timer_state;
reg [22:0] timer_phase;

wire [8:0] timer_step = 9'd38 + {1'b0,timer_reg};
wire [23:0] timer_sum = {1'b0,timer_phase} + {{15{1'b0}},timer_step};

always @(posedge clk) begin
    if (rst) begin
        timer_reg    <= 8'd0;
        timer_enable <= 1'b0;
        timer_state  <= 1'b0;
        timer_phase  <= 23'd0;
    end else begin
        // CPU-visible timer programming.
        if (cs && we) begin
            if (addr == 9'h127) begin
                timer_reg   <= din;
                timer_phase <= 23'd0;
                timer_state <= 1'b0;
            end
            if (addr == 9'h12f) begin
                timer_enable <= din[5];
                if (!din[5]) begin
                    timer_phase <= 23'd0;
                    timer_state <= 1'b0;
                end
            end
        end

        if (cen && timer_enable) begin
            if (timer_sum >= 24'd2764800) begin
                timer_phase <= timer_sum - 24'd2764800;
                timer_state <= ~timer_state;
            end else begin
                timer_phase <= timer_sum[22:0];
            end
        end
    end
end

assign timeout = timer_enable ? timer_state : 1'b0;

/*
 * Auxiliary stereo mixer.
 *
 * Public JTCORES uses aux_l/aux_r to cascade two K054539 instances.
 * Saturation is preferable to wrap-around when both chips approach full scale.
 */
wire signed [16:0] mix_l = {pcm_l[15],pcm_l} + {aux_l[15],aux_l};
wire signed [16:0] mix_r = {pcm_r[15],pcm_r} + {aux_r[15],aux_r};

function signed [15:0] sat16;
    input signed [16:0] v;
    begin
        if (v > 17'sd32767)
            sat16 = 16'sh7fff;
        else if (v < -17'sd32768)
            sat16 = 16'sh8000;
        else
            sat16 = v[15:0];
    end
endfunction

assign left  = sat16(mix_l);
assign right = sat16(mix_r);

endmodule
