#!/usr/bin/env bash
set -euo pipefail

# Run from modules/jt539, or from anywhere after copying this package there.
HERE="$(cd "$(dirname "$0")" && pwd)"
HDL="$HERE/hdl"
BASE="https://raw.githubusercontent.com/jlrh/konami-fpga/main/cores/moomesa/hdl"

mkdir -p "$HDL"

for f in k054539.v voltab.hex pantab.hex rram_zero.hex; do
    echo "Fetching $f"
    curl -fL "$BASE/$f" -o "$HDL/$f"
done

echo
echo "Fetched open K054539 backend into:"
echo "  $HDL"
echo
echo "Now build a JTCORE which uses jt539, for example:"
echo "  source setprj.sh"
echo "  jtcore rungun -mister -c"
