
module k054539 #(parameter VOLSHIFT=0)(
 input rst,clk,cen, output timeout,
 input [8:0] addr, input we,rd,cs, input [7:0] din, output [7:0] dout,
 output rom_cs, output [23:0] rom_addr, input [7:0] rom_data, input rom_ok,
 output signed [15:0] left,right, input [7:0] debug_bus, output [7:0] st_dout
);
assign timeout=0; assign dout=0; assign rom_cs=0; assign rom_addr=0;
assign left=0; assign right=0; assign st_dout=0;
endmodule
